% Hanan Alshatti 101137569

function v_full = V_node_grid_voltage(V_node, W)

v_mat       = zeros(30,100);
for i=1:30
    for j=1:100
        v_mat(i,j)=V_node((i-1)*100+j);
    end
end

v_full              = zeros(60,100);
v_full(1:30,1:100)  = v_mat;
s   = W/2;

for i=W/2:-1:1
    s           = s+1;
    v_full(s,:) = v_mat(i,:);
end

end % end of function
