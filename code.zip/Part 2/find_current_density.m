% Hanan Alshatti 101137569


function [ J_x, J_y ] = find_current_density(E_x, E_y,sigma_1,sigma_2);

sigma_avrg      = (sigma_1+sigma_2)/2;

J_x     = zeros(60,99);
for i=1:60
    for j=1:99
        if(i < 11 && j > 40 && j < 60 )
            if( i == 10 )
                J_x(i,j) = E_x(i,j)*sigma_avrg;
            end
            J_x(i,j)   = E_x(i,j)*sigma_2;
        else
            J_x(i,j)   = E_x(i,j)*sigma_1;
        end
        
    end
end

J_y     = zeros(100,59);
for j=1:100
    for i=1:59
        if((j==40||j==60)&&(i<10||i>50))
           J_y(i,j)=E_y(i,j)*sigma_avrg;  
        else
            if((i<10||i>50) &&j>39 && j<60)
                J_y(i,j)=E_y(i,j)*sigma_2;
            else
                J_y(i,j)=E_y(i,j)*sigma_1;
            end
        end
    end
end

end