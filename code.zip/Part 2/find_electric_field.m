% Hanan Alshatti 101137569

function [ E_x, E_y ]    = find_electric_field(v_full,deltax)

E_x     = zeros(60,99);
for i=1:60
    for j=1:99
        E_x(i,j)=-(v_full(i,j+1)-v_full(i,j))/deltax;
    end
end

E_y     = zeros(59,100);
for j=1:100
    for i=1:59
        E_y(i,j)=-(v_full(i+1,j)-v_full(i,j))/deltax;
    end
end

end % end of function