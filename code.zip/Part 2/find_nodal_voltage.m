% Hanan Alshatti 101137569

function V_node  = find_nodal_voltage(sigma_1,sigma_2, L, W,W_i)

sigma_avrg  = (sigma_1+sigma_2)/2;
W_half      = W/2;
No_nodes    = L*W_half;
x_grid      = linspace(1,L,100);
y_grid      = linspace(1,W_half,30);
Mat         = zeros(No_nodes,No_nodes);
mat1        = eye(100);

RHS=zeros(No_nodes,1);
Mat(1:100,1:100)=mat1;
for i=2:max(size(y_grid))-1
    for j=1:max(size(x_grid))
        n_n=(i-1)*100+j;
        if(j==1||j==100)
            Mat(n_n,n_n)=1;
        else
            %%Small area of conductivity
            if(j>40&&j<60&&i>1&&i<W_i)
                Mat(n_n,n_n)=-4*sigma_2;
                Mat(n_n,n_n+1)=1*sigma_2;
                Mat(n_n,n_n-1)=1*sigma_2;
                Mat(n_n,n_n+100)=1*sigma_2;
                Mat(n_n,n_n-100)=1*sigma_2;
                %%Large area where sigma_1=1
            else
                Mat(n_n,n_n)=-4*sigma_1;
                Mat(n_n,n_n+1)=1*sigma_1;
                Mat(n_n,n_n-1)=1*sigma_1;
                Mat(n_n,n_n+100)=1*sigma_1;
                Mat(n_n,n_n-100)=1*sigma_1;
                
            end
        end
        %%%%Redifining boundary nodes with average conductivity%%%
        if(j==40&&i<W_i)
            Mat(n_n,n_n)=-(sigma_1+sigma_2+2*sigma_avrg);
            Mat(n_n,n_n+1)=sigma_2;
            Mat(n_n,n_n-1)=sigma_1;
            Mat(n_n,n_n+100)=sigma_avrg;
            Mat(n_n,n_n-100)=sigma_avrg;
        end
        if(j==60&&i<W_i)
            Mat(n_n,n_n)=-(sigma_1+sigma_2+2*sigma_avrg);
            Mat(n_n,n_n+1)=sigma_1;
            Mat(n_n,n_n-1)=sigma_2;
            Mat(n_n,n_n+100)=sigma_avrg;
            Mat(n_n,n_n-100)=sigma_avrg;
        end
        if(i==W_i&&j>40&&j<60)
            Mat(n_n,n_n)=-(sigma_1+sigma_2+2*sigma_avrg);
            Mat(n_n,n_n+1)=sigma_avrg;
            Mat(n_n,n_n-1)=sigma_avrg;
            Mat(n_n,n_n+100)=sigma_1;
            Mat(n_n,n_n-100)=sigma_2;
        end
        if(i==W_i&&j==40)
            Mat(n_n,n_n)=-(sigma_1+sigma_2+2*sigma_avrg);
            Mat(n_n,n_n+1)=sigma_avrg;
            Mat(n_n,n_n-1)=sigma_1;
            Mat(n_n,n_n+100)=sigma_2;
            Mat(n_n,n_n-100)=sigma_avrg;
        end
        if(i==W_i&&j==60)
            Mat(n_n,n_n)=-(sigma_1+sigma_2+2*sigma_avrg);
            Mat(n_n,n_n+1)=sigma_1;
            Mat(n_n,n_n-1)=sigma_avrg;
            Mat(n_n,n_n+100)=sigma_2;
            Mat(n_n,n_n-100)=sigma_avrg;
        end
        if(j==1)
            RHS(n_n,1)=10;
        end
    end
end
for i=2901:3000
    Mat(i,i)=1;
    Mat(i,i-100)=-1;
end
V_node=Mat\RHS;
end