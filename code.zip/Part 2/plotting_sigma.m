function plotting_sigma( sigma1,sigma2,x_grid,y_grid_new,w_i )
sigma_mat=zeros(60,100);
   for j=1:100
       for i=1:60
           if (i<w_i&&j>40&&j<60 || i>60-w_i&&j>40&&j<60)
               sigma_mat(i,j)=sigma2;
           else
               sigma_mat(i,j)=sigma1;

           end
       end
   end
[X,Y]       = meshgrid(x_grid,y_grid_new);
figure;
surf(X,Y,sigma_mat)
view(2);
title('variation of sigma plot');
end


