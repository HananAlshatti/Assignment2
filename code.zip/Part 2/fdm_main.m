% Hanan Alshatti 101137569




close all;
clear all;
clc;


sigma_1     = 1;
sigma_2     = 0.5;
sigma_avrg  = (sigma_1+sigma_2)/2;
w_i         =10; %% Width of the interface
L           = 100;
W           = 60;

V_node      = find_nodal_voltage(sigma_1,sigma_2, L, W,w_i);

v_full      = V_node_grid_voltage(V_node, W);
figure;


x_grid      = linspace(1,L,100);
y_grid      = linspace(1,W/2,30);
y_grid_new  = linspace(1,W,60); 
plotting_sigma( sigma_1,sigma_2,x_grid,y_grid_new,w_i );
[X,Y]       = meshgrid(x_grid,y_grid_new);

figure;
surf(X,Y,v_full)
view(2)

figure;
[cc,hh]     = contour(X,Y,v_full,'ShowText','on','linewidth',3);
grid on;


%%%%%%%%%%%%%%Electric Field%%%%%%%%%%%%%%%%%%%
deltax          = x_grid(3)-x_grid(2);
[ E_x, E_y ]    = find_electric_field(v_full,deltax);


x_middle    = zeros(99,1);
for i=1:99
    x_middle(i)     = (x_grid(i+1)+x_grid(i))/2;
end

y_middle    = zeros(59,1);
for i=1:59
    y_middle(i)     = (y_grid_new(i+1)+y_grid_new(i))/2;
end

[X_m,Y_m]       = meshgrid(x_middle,y_grid_new);
figure;
surf(X_m,Y_m,E_x)
view(2)

[X_m_d,Y_m_d]   = meshgrid(x_grid,y_middle);
figure;
surf(X_m_d,Y_m_d,E_y)
view(2)

%%%%%%%%%Current density plot%%%%%%%%%%%%%%%
[ J_x, J_y ]    = find_current_density(E_x, E_y,sigma_1,sigma_2);

figure;
surf(X_m,Y_m,J_x)   
view(2)
%%%%%%%%Different Sigma%%%%%%%%%%%%%%%%%%%%%%
 sigma_1_d=0.5;  
 V_node_d      = find_nodal_voltage(sigma_1_d,sigma_2, L, W,w_i);
 v_full_d      = V_node_grid_voltage(V_node_d, W);
 plot(v_full_d(10,:),'--')
hold on
plot(v_full(10,:),'o')
[ E_x_d, E_y_d ]    = find_electric_field(v_full_d,deltax);
plot(E_x_d(10,:))
hold on
plot(E_x(10,:),'o')
[ J_x_d, J_y_d ]    = find_current_density(E_x_d, E_y_d,sigma_1_d,sigma_2);
%%%%%%Increasing the interface width%%%%%%%%%%%%%
w_i=20;
V_node_new      = find_nodal_voltage(sigma_1,sigma_2, L, W,w_i);
v_full_new      = V_node_grid_voltage(V_node_new, W);
plot(v_full_new(20,:),'--');
plotting_sigma( sigma_1,sigma_2,x_grid,y_grid_new,w_i );
figure;
surf(X,Y,v_full_new)
view(2)
[ E_x_new, E_y_new ]    = find_electric_field(v_full_new,deltax);
plot(E_x_new(10,:))
[ J_x_new, J_y_new ]    = find_current_density(E_x_new, E_y_new,sigma_1_d,sigma_2);

        