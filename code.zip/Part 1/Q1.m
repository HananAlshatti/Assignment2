% Hanan Alshatti 101137569
close all;
clear all;
clc;
L      =     90;
W      =     60;
V0     =     1;
x_grid =     linspace(1,L,90);
y_grid =     linspace(1,L,60);
No_of_nodes = L*W;
Mat    =      zeros(No_of_nodes,No_of_nodes);
RHS=zeros(No_of_nodes,1);
for i=1:60
    for j=1:90
        n_n=(i-1)*90+j;
        if (j==1||j==90)
              Mat(n_n,n_n)=1;
              if(j==1)
                  RHS(n_n,1)=1;
              end
        end
            if (i==1||i==60)
              Mat(n_n,n_n)=1;
              if(i==1)
                 Mat(n_n,n_n+90)=-1;
              end
              if(i==60)
                  Mat(n_n,n_n-90)=-1;
              end
             end
          if(i~=1&&i~=60&&j~=1&&j~=90)
          Mat(n_n,n_n)=-4;
         Mat(n_n,n_n+1)=1;
          Mat(n_n,n_n-1)=1;
          Mat(n_n,n_n+90)=1;
          Mat(n_n,n_n-90)=1;
         end
    end
end
Mat(1,91)=0;
RHS(5311,1)=0;
V_node=Mat\RHS;
v_mat       = zeros(60,90);
for i=1:60
    for j=1:90
        v_mat(i,j)=V_node((i-1)*90+j);
    end
end
[X,Y]       = meshgrid(x_grid,y_grid);
figure;
plot(x_grid,v_mat(12,:))

%%%%%%%%Question 2%%%%%%%%%%%%%%
Mat    =      zeros(No_of_nodes,No_of_nodes);
RHS=zeros(No_of_nodes,1);
for i=1:60
    for j=1:90
         n_n=(i-1)*90+j;
          if(i~=1&&i~=60&&j~=1&&j~=90)
          Mat(n_n,n_n)=-4;
         Mat(n_n,n_n+1)=1;
          Mat(n_n,n_n-1)=1;
          Mat(n_n,n_n+90)=1;
          Mat(n_n,n_n-90)=1;
          end
         if(i==1||i==60||j==1||j==90)
           Mat(n_n,n_n)=1;
         end
         if(j==1||j==90)
           RHS(n_n,1)=1;
         end
             
    end
end
 V_node_new=Mat\RHS;
v_mat       = zeros(60,90);
for i=1:60
    for j=1:90
        v_mat(i,j)=V_node_new((i-1)*90+j);
    end
end
[X,Y]       = meshgrid(x_grid,y_grid);
figure;
surf(X,Y,v_mat);

%%%%%%%%%Analytical Solution%%%%%%%%%%%%%%%%
figure;
psum=zeros(60,90);
v_analy=zeros(60,90);
x=linspace(-45,45,90);
y=linspace(0,60,60);
for n=1:2:100
   for i=1:60
       for j=1:90
           s1=cosh(n*pi*x(j)/60)/(n*cosh(n*pi*45/60));
           s2=sin(n*pi*y(i)/60);
           psum(i,j)=s1*s2;
       end
   end
   v_analy=v_analy+(4/pi)*psum;
   surf(X,Y,v_analy);
   pause(1)
end
figure;
plot(x,v_analy(30,:));
hold on;
plot(x,v_mat(30,:),'o');
title('comparison of analytic and numeric at line parallel to x axis at half the height');
        

